// declare global variable "D"
window.D = {
    // types
    Load:null,
    GameManager: null,
    // singletons
    game: null,
    pipeManager: null,
    sceneManager: null,
    starManager: null,
    drillerManager: null,
    sheep: null,
};
