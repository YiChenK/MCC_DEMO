
cc.Class({
    extends: cc.Component,

    properties: {
        codeEdit : {
            type : cc.EditBox,
            default : null,
            tooltip : "验证码",
        },
        phoneEdit : {
            type : cc.EditBox,
            default : null,
            tooltip : "手机号",
        },

        codeBtn : {
            type : cc.Button,
            default : null,
            tooltip : "验证码",
        },
        phoneBtn : {
            type : cc.Button,
            default : null,
            tooltip : "手机号",
        },

        code  : {
            default : "",
            visible : false,
        },
        phone  : {
            default : "",
            visible : false,
        },

    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        cc.mm.Load = this;

        if ( !cc.mm.FIREST )
        {
            this.node.active = true;
        }
        else
        {
            this.node.active = false;
        }
    },

    /**
     * 获取手机验证码
     */
    CodeCallBack : function ()
    {
        if( cc.mm.Tool.IsNullOrEmpty( this.phoneEdit.string ) || cc.mm.Tool.IsVirtualNumber( this.phoneEdit.string ) ) return;

        else cc.mm.Load.phone = this.phoneEdit.string;

        let self = this;
        let label = this.codeBtn.node.getChildByName( "Hint" ).getComponent( cc.Label );
        
        if( label )
        {
            this.codeBtn.interactable = false;              // make the button unclickable

            let count = 40;                                 // the time interval for obtaining the captcha
            let json = { tel : cc.mm.Load.phone, area : "86" };          // incoming parameter

            cc.mm.Request.PhoneCode(

                json,
                () => { },
                () => 
                {
                    label.string = "get code";
                    self.codeBtn.interactable = true;
                    self.codeBtn.unschedule( time ); 
                },
            );

            var time = function (dt)                        // timer callback fun
            {
                count--;                                    // count down
                label.string = count;                       // show time

                if ( count === 0 )                          
                {
                    label.string = "get code";              // show hint
                    self.codeBtn.interactable = true;       // make the button clickable
                    self.codeBtn.unschedule( time );        // close timer
                }
            };

            self.codeBtn.schedule( time, 1 );               // open timer
        }
    },

    /**
     * 按钮调用手机号登陆
     */
    LoginCallBack : function ()
    {
        let self = this;

        //if ( cc.mm.Tool.IsNullOrEmpty( self.codeEdit.string ) ) return;

        //else cc.mm.Load.code = self.codeEdit.string;

        //if ( cc.mm.Tool.IsNullOrEmpty( self.phoneEdit.string ) || cc.mm.Tool.IsVirtualNumber( self.phoneEdit.string ) ) return;

        //else cc.mm.Load.phone = self.phoneEdit.string;

        // 默认已经写死的， 直接点击登录就好。 如果想要手输，取消上面屏蔽即可
        // 所需参数， 获取的验证码，用户的手机号，手机号所载区号，  大陆为+86

        self.phoneBtn.interactable = false;

        let json = { tel : "13614171941", code : "1324", area : "86" };

        cc.mm.Request.PhoneLogin(

            json,
            success => 
            {
                cc.mm.Config.OPENID = success.openid;

                cc.mm.FIREST = true;

                this.node.active = false;

                D.game.gameStart();
            },
            () => 
            { 
                self.phoneBtn.interactable = true; 
            },
        );
    },
});
