// android 都是普通浏览器
// require("WebDeal").startWeb(); Wkwebview
// IOS  startWeb();  为高级浏览器 性能更好，耗费资源更少。
module.exports.startWeb = function (url) {
    // 开启普通浏览器
    if (cc.sys.isNative) {
        if (cc.sys.os == cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod("webview/WebDeal", "startWeb", "(Ljava/lang/String;)V", url);
        } else {
            jsb.reflection.callStaticMethod("WebDeal", "startWeb:", url);
        }
    } else{
        // window.open(url);
        // window.location.href = url;
        cc.sys.openURL(url);
    }
};

// require("WebDeal").startUIWeb(); UIwebview
// IOS  startUIWeb();  为低级浏览器 性能较差，耗费资源稍多。
module.exports.startUIWeb = function (url) {
    if (cc.sys.isNative) {
        if (cc.sys.os == cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod("webview/WebDeal", "startWeb", "(Ljava/lang/String;)V", url);
        } else {
            jsb.reflection.callStaticMethod("WebDeal", "startUIWeb:", url);
        }
    } else{
        // window.location.href = url;
        cc.sys.openURL(url);
        // window.open(url);
    }
};