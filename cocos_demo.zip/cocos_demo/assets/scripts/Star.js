cc.Class({
    extends: require('SceneObject'),
});
