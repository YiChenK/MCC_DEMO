// create bg YiChen
// @ Magic Cube
// 2018 /8/

var LogCtrl = {
    
    isSend : 0,
    console : 1,

    LOG : cc.Enum( { FALSE:0, TRUE:1 } ),

    Json : function ( json )
    {
        if( this.console == this.LOG.TRUE )
        {
            console.log( "Json___" , json );
        }
    },

    Print : function ( info )
    {
        if( this.console == this.LOG.TRUE )
        {
            console.log( "Print___" , info );
        }
    },

    Error : function ( info )
    {
        if( this.console == this.LOG.TRUE )
        {
            console.log( "Error___" , info );
        }
    },

    Warning : function ( info )
    {
        if( this.console == this.LOG.TRUE )
        {
            console.log( ">>>" + info + "<<<" );
        }
    },

    Success : function ( name, info )
    {
        if( this.console == this.LOG.TRUE )
        {
            console.log( "Success___" , name, info );
        }
    },

    Failure : function ( name, info )
    {
        if( this.console == this.LOG.TRUE )
        {
            console.log( "Failure___" , name, info );
        }
    },

    Resolve : function ( name, json )
    {
        if( this.console == this.LOG.TRUE )
        {
            console.log( "Resolve___" , name, json );
        }
    },

    Reject  : function ( name, json )
    {
        if( this.console == this.LOG.TRUE )
        {
            console.log( "Reject___" , name, json );
        }
    },

    PortNormal : function ()
    {
        if( this.console == this.LOG.TRUE )
        {
            console.log( ">>> NO NEED CALLBACK <<<" );
        }
    },
    
    PortFunName : function ( method )
    {
        if( this.console == this.LOG.TRUE )
        {
            console.log( ">>>" + method + "IS RETURN FAILED <<<" );
        }
    },

    PortFunInfo : function ( method, data )
    {
        if( this.console == this.LOG.TRUE )
        {
            console.log( ">>>" + method + data + "<<<" );
        }
    },

    Socket_Send : function ( route, data )
    {
        let debug = {
            TITLE : "REQUEST_TO_SEND_MSG",
            TIME : new Date(),
            PORT : route,
            DATA : data,
        };

        console.log(debug);
    },

    Socket_Event : function ( route, data )
    {
        let debug = {
            TITLE : "RECEIVE_TRANSMIT_MSG",
            TIME : new Date(),
            PORT : route,
            DATA : data,
        };

        console.log(debug);
    },

    Socket_Error : function ( route, data, error )
    {
        let debug = {
            TITLE : "--------ERROR--------",
            TIME : new Date(),
            PORT : route,
            DATA : data,
        };

        if ( error )
        {
            console.log(error);
        }

        console.log(debug);
    },

    Socket_Receive : function ( route, data )
    {
        let debug = {
            TITLE : "RECEIVE_RESPONSE_MSG",
            TIME : new Date(),
            PORT : route,
            DATA : data,
        };

        console.log(debug);
    },
};

module.exports = LogCtrl;