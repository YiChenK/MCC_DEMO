(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/DrillerManager.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '9d752VBYEJPOqiPJAYcWU+2', 'DrillerManager', __filename);
// scripts/DrillerManager.js

'use strict';

var Driller = require('Driller');

cc.Class({
    extends: cc.Component,
    properties: {
        prefab: cc.Prefab,
        spawnInterval: 1
    },
    onLoad: function onLoad() {
        D.drillerManager = this;
    },
    start: function start() {
        this.schedule(this.spawn, this.spawnInterval);
    },

    //-- 创建管道组
    spawn: function spawn() {
        D.sceneManager.spawn(this.prefab, Driller);
    },
    reset: function reset() {
        this.unschedule(this.spawn);
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=DrillerManager.js.map
        