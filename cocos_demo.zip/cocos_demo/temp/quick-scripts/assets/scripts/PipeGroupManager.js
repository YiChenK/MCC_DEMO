(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/PipeGroupManager.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'ded04ocxo1Pcopg6kafVPGn', 'PipeGroupManager', __filename);
// scripts/PipeGroupManager.js

'use strict';

var PipeGroup = require('PipeGroup');

cc.Class({
    extends: cc.Component,
    properties: {
        pipePrefab: cc.Prefab,
        //-- 创建PipeGroup需要的时间
        spawnInterval: 0
    },
    onLoad: function onLoad() {
        D.pipeManager = this;
    },
    startSpawn: function startSpawn() {
        this.spawnPipe();
        this.schedule(this.spawnPipe, this.spawnInterval);
    },

    //-- 创建管道组
    spawnPipe: function spawnPipe() {
        D.sceneManager.spawn(this.pipePrefab, PipeGroup);
    },
    reset: function reset() {
        this.unschedule(this.spawnPipe);
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=PipeGroupManager.js.map
        