(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/GameManager.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '327f03mWlNHJqsi+VEpOBXC', 'GameManager', __filename);
// scripts/GameManager.js

'use strict';

var Sheep = require('Sheep');
var Scroller = require('Scroller');

var State = cc.Enum({
    Menu: -1,
    Run: -1,
    Over: -1
});

var GameManager = cc.Class({
    extends: cc.Component,
    //-- 属性
    properties: {
        //-- 获取绵羊
        sheep: Sheep,
        //-- 获取gameOverMenu对象
        gameOverMenu: cc.Node,
        //-- 获取分数对象
        scoreText: cc.Label,
        //-- 获取背景音效
        gameBgAudio: {
            default: null,
            type: cc.AudioClip
        },
        //-- 获取死亡音效
        dieAudio: {
            default: null,
            type: cc.AudioClip
        },
        //-- 获取失败音效
        gameOverAudio: {
            default: null,
            type: cc.AudioClip
        },
        //-- 获取得分音效
        scoreAudio: {
            default: null,
            type: cc.AudioClip
        },

        supermanMode: {
            default: false,
            tooltip: '无敌模式, 方便测试地图'
        }
    },

    statics: {
        State: State
    },

    onLoad: function onLoad() {
        if (cc.mm == null) cc.mm = {};
        D.GameManager = GameManager;
        D.game = this;

        cc.mm.Http = window.Http; // 初始化 通信基础
        cc.mm.Tool = require("Tool"); // 初始化 工具脚本
        cc.mm.LogMgr = require("LogMgr"); // 初始化 日志系统
        cc.mm.Config = require("NetConfig"); // 初始化 本地配置
        cc.mm.HttpMgr = require("HttpMgr"); // 初始化 短链管理
        cc.mm.Request = require("HttpRequest"); // 初始化 通信请求

        cc.mm.Config.InitConfig(cc.mm.Config.ENUM_ENVIR.LOCAL); // 切换至 本地分支

        // activate colliders
        cc.director.getCollisionManager().enabled = true;

        //-- 游戏状态
        this.state = State.Menu;
        //-- 分数
        this.score = 0;
        this.scoreText.string = this.score;
        this.gameOverMenu.active = false;
        this.sheep.init();

        if (cc.mm.Tool.IsNullOrEmpty(cc.mm.FIREST)) {
            cc.mm.FIREST = false;
        } else if (cc.mm.FIREST) {
            setTimeout(function () {
                D.game.gameStart();
            }, 500);
        }
    },

    //-- 开始
    gameStart: function gameStart() {

        this.state = State.Run;
        this.score = 0;
        cc.audioEngine.playMusic(this.gameBgAudio);
        D.pipeManager.startSpawn();
        D.starManager.start();
        D.drillerManager.start();
        this.sheep.startRun();
    },
    gameOver: function gameOver() {
        //-- 背景音效停止，死亡音效播放
        cc.audioEngine.stopMusic();
        cc.audioEngine.playEffect(this.dieAudio);
        cc.audioEngine.playEffect(this.gameOverAudio);
        D.pipeManager.reset();
        D.starManager.reset();
        D.drillerManager.reset();
        this.state = State.Over;
        this.gameOverMenu.active = true;
        this.gameOverMenu.getComponent('GameOverMenu').score.string = this.score;
    },

    //-- 更新分数
    gainScore: function gainScore() {

        var json = { openid: cc.mm.Config.OPENID };

        var self = this;

        // 每过一个管道，就相当于一次挖矿行为，向服务器请求本次挖矿行为。
        cc.mm.Request.UserCreate(json, function (success) {
            //-- 分数+1
            self.score++;
            self.scoreText.string = self.score;
            //-- 分数增加音效
            cc.audioEngine.playEffect(self.scoreAudio);
        }, function (failure) {
            console.log("分数更新失败");
        });
    },


    // 按钮跳转四叶草分红界面/交易所界面
    skipExchange: function skipExchange() {
        require("WebDeal").startWeb("http://m.slot.magiccube.io/mcc/#/market"); //http://192.168.4.200:8080/#/market
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GameManager.js.map
        