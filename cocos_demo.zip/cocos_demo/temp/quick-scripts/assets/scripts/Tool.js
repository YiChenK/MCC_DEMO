(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/Tool.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'ec42aoJP4RM2aElzXldbkiW', 'Tool', __filename);
// scripts/Tool.js

"use strict";

// create bg YiChen
// @ Magic Cube
// 2018 /8/

var Tool = {

    MONEY: cc.Enum({ OW: 5, QW: 8, BI: 9 }),

    //#region  Judge

    /**
     * Whether the text contains only Spaces ?
     */
    IsBlank: function IsBlank(text) {
        var blank = /^\s*$/;

        return text.match(blank) !== null;
    },

    /** 
     * The Obj is Null or Empty ?
     */
    IsNullOrEmpty: function IsNullOrEmpty(obj) {
        if (typeof obj == "undefined" || obj == null || obj == "null" || obj == "") {
            return true;
        } else {
            return false;
        }
    },

    /**
     * 判断数据对象是否为空
     * @param {*} obj 输入对象
     */
    IsEmptyObject: function IsEmptyObject(obj) {
        for (var key in obj) {
            return false;
        }
        return true;
    },

    /** 
     * The Phone number is Virtual number ?
     */
    IsVirtualNumber: function IsVirtualNumber(phone) {
        /* 
        * 大陆手机号码11位数，匹配格式：前三位固定格式+后8位任意数 
        * 此方法中前三位格式有： 
        * 13+任意数 
        * 15+任意数 
        * 18+任意数 
        * 17+任意数 虚拟号码 黑名单
        * 147 
        */

        if (/^(17[0-1])\d{8}$/.test(phone)) //黑名单 170 171 虚拟号码 
            {
                cc.mm.Hint.ShowHintPush("暂不支持虚拟号码进行注册");

                return true;
            } else {
            cc.mm.LogMgr.Print("除虚拟号码外即可注册");

            return false;
        }

        // if( ( /^( 1[0-9][0-9] | (13[0-9]) | (15[0-9]) | (18[0-9]) | (17[0-9]) | (147) )\d{8}$/.test( phone ) ) ) //白名单
        // { 
        //     alert("手机号码有误，请重填");  
        //     return false; 
        // } 
    },

    /** 
     * Whether to open the page inside the WeChat ?
     */
    IsWeixinBrowser: function IsWeixinBrowser() {
        var ua = navigator.userAgent.toLowerCase();

        return !!/micromessenger/.test(ua);
    },

    //#endregion

    //#region  The numerical changes

    /** 
     * 四舍五入取整
     */
    ToInteger: function ToInteger(number) {
        var num = number.toFixed(0) - number.toFixed(1);

        if (num > 0.3) {
            return number.toFixed(0) + 1;
        } else {
            return number.toFixed(0);
        }
    },

    /** 
     * 返回带有正负号的财富值
     */
    GetSymbol: function GetSymbol(wealth) {
        if (wealth > 0) {
            this.symbol = "+";
        } else {
            this.symbol = "";
        }

        return this.symbol;
    },

    /** 
     * 数值显示更改： 
     * 过万显示 “万” 单位...
     * @param {*} value 要更改的数值
     * */
    ToPointValue: function ToPointValue(value) {
        var length = value.toString().length;

        if (length < this.MONEY.OW) {
            return value;
        } else if (length >= this.MONEY.OW && length < this.MONEY.BI) {
            return (value / 10000).toFixed(1) + "万";
        } else if (length >= this.MONEY.BI) {
            return (value / 10000 / 10000).toFixed(2) + "亿";
        }
    },

    /** 
     * 以百分比显示
     * @param {*} number 传入百分比
     * */
    ReturnString: function ReturnString(number) {
        if (number == 0) {
            return "无";
        } else if (1 - number >= 0) {
            return number * 100 + "%";
        } else {
            return number;
        }
    },

    //#endregion


    //#region  Cocos Config

    /**
     * 设置obj的状态
     * @param {*} obj 输入对象  (node component ...)
     * @param {*} state 状态值  true OR false
     */
    ObjActive: function ObjActive(obj, state) {
        if (obj) {
            obj.node.active = state;
        } else {
            cc.mm.LogMgr.Print(obj + " is null");
        }
    },

    /**  
     * 设置node的大小
     */
    SetNodeScale: function SetNodeScale(node) {
        var scale = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;

        if (node) {
            node.setScale(scale);
        }
    },

    /**  
     * 设置node的父级
     */
    SetNodeParent: function SetNodeParent(node, parent) {
        if (node && parent) {
            node.setParent(parent);
        }
    },

    /**  
     * 设置node的位置
     */
    SetNodePosition: function SetNodePosition(node, position) {
        if (node) {
            node.setPosition(position);
        }
    },

    SetNodePositionXY: function SetNodePositionXY(node, x, y) {
        if (node) {
            node.setPosition(x, y);
        }
    },

    /**  
     * 设置node的旋转
     */
    SetNodeRotation: function SetNodeRotation(node, rotation) {
        if (node) {
            node.setRotation(rotation);
        }
    }

    //#endregion

};

module.exports = Tool;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Tool.js.map
        