(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/Driller.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '4c008xCm+xJSLzvNSxTP2bJ', 'Driller', __filename);
// scripts/Driller.js

'use strict';

function getDir(node) {
    var degree_cw = node.rotation;
    var degree_ccw = -degree_cw;
    var down = new cc.Vec2(0, -1);
    return down.rotateSelf(degree_ccw * Math.PI / 180);
}

cc.Class({
    extends: require('SceneObject'),

    properties: {
        velocity: {
            default: 5
        },
        angleVelocity: 5,

        v2: cc.Vec2
    },

    onEnable: function onEnable() {
        this.v2 = new cc.Vec2(0, -3.5);
        this.node.y = 0;
    },
    update: function update(dt) {
        // look at player
        //var targetPos = D.sheep.node.position;
        var selfPos = this.node.position;
        //var expectedDir = targetPos.sub(selfPos).normalizeSelf();
        //var selfDir = getDir(this.node);
        //var isLeft = selfDir.cross(expectedDir) > 0;
        // if (isLeft) {
        //     this.node.rotation += this.angleVelocity * dt;
        // }
        // else {
        //     this.node.rotation -= this.angleVelocity * dt;
        // }

        // move forward
        //var speed = getDir(this.node).mul(this.velocity * dt);

        this.node.position = selfPos.add(this.v2);
    },
    onCollisionEnter: function onCollisionEnter() {
        D.sceneManager.despawn(this);
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Driller.js.map
        