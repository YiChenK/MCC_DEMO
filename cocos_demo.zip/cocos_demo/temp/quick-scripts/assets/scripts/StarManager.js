(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/StarManager.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'a3540dMSbNA0IxpobUt8I4j', 'StarManager', __filename);
// scripts/StarManager.js

'use strict';

var Star = require('Star');

cc.Class({
    extends: cc.Component,
    properties: {
        starPrefab: cc.Prefab,
        spawnInterval: 2,
        probableValue: {
            default: 0.1,
            tooltip: '生成星星的概率'
        }
    },
    onLoad: function onLoad() {
        D.starManager = this;
    },
    start: function start() {
        this.schedule(this.spawn, this.spawnInterval, cc.macro.REPEAT_FOREVER, this.spawnInterval / 2);
    },
    spawn: function spawn() {
        if (Math.random() > this.probableValue) {
            return;
        }
        var star = D.sceneManager.spawn(this.starPrefab, Star);
        star.node.y = -270 + Math.random() * (325 + 270);
    },
    reset: function reset() {
        this.unschedule(this.spawn);
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=StarManager.js.map
        