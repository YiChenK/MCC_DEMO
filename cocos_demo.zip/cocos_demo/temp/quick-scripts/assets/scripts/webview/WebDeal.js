(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/webview/WebDeal.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'e0a62Bk/hFIe608pji5xFKk', 'WebDeal', __filename);
// scripts/webview/WebDeal.js

"use strict";

// android 都是普通浏览器
// require("WebDeal").startWeb(); Wkwebview
// IOS  startWeb();  为高级浏览器 性能更好，耗费资源更少。
module.exports.startWeb = function (url) {
    // 开启普通浏览器
    if (cc.sys.isNative) {
        if (cc.sys.os == cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod("webview/WebDeal", "startWeb", "(Ljava/lang/String;)V", url);
        } else {
            jsb.reflection.callStaticMethod("WebDeal", "startWeb:", url);
        }
    } else {
        // window.open(url);
        // window.location.href = url;
        cc.sys.openURL(url);
    }
};

// require("WebDeal").startUIWeb(); UIwebview
// IOS  startUIWeb();  为低级浏览器 性能较差，耗费资源稍多。
module.exports.startUIWeb = function (url) {
    if (cc.sys.isNative) {
        if (cc.sys.os == cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod("webview/WebDeal", "startWeb", "(Ljava/lang/String;)V", url);
        } else {
            jsb.reflection.callStaticMethod("WebDeal", "startUIWeb:", url);
        }
    } else {
        // window.location.href = url;
        cc.sys.openURL(url);
        // window.open(url);
    }
};

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=WebDeal.js.map
        