(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/http/HttpRequest.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '85309PkO+lIlI9Mk+V9xnKE', 'HttpRequest', __filename);
// scripts/http/HttpRequest.js

"use strict";

// create bg YiChen
// @ Magic Cube
// 2018 /8/

var Request = {

  /**
   * 返回数据消息
   * @param {*} data 返回数据
   */
  Message: function Message(data) {
    return data.message;
  },

  /**
   * 处理Message（弹窗提示等等）
   * @param {*} message 消息
   */
  DealMessage: function DealMessage(message) {
    //do something
    cc.mm.Hint.ShowShort("", message, true);
  },

  //#region 


  /** 
   * 获取 Phone Code
   * 
   * 参数 phone
   */
  PhoneCode: function PhoneCode(json, sucFn, faiFn) {
    cc.mm.HttpMgr.Post(cc.mm.Config.URL_LOGIN_CODE, function (success) {
      if (sucFn) {
        sucFn(success);
      }
    }, function (failure) {
      if (faiFn) {
        faiFn(failure);
      }
    }, "PhoneCode", json);
  },

  /** 
   * 手机登录
   * 
   * 参数 phone code
   */
  PhoneLogin: function PhoneLogin(json, sucFn, faiFn) {
    cc.mm.HttpMgr.Post(cc.mm.Config.URL_USER_LOGIN, function (success) {
      if (sucFn) {
        sucFn(success);
      }
    }, function (failure) {
      if (faiFn) {
        faiFn(failure);
      }
    }, "PhoneLogin", json);
  },

  /** 
   * 挖矿行为
   * 
   * 参数 
   */
  UserCreate: function UserCreate(json, sucFn, faiFn) {
    cc.mm.HttpMgr.Post(cc.mm.Config.URL_USER_CREAT, function (success) {
      if (sucFn) {
        sucFn(success);
      }
    }, function (failure) {
      if (faiFn) {
        faiFn(failure);
      }
    }, "UserCreate", json);
  }

  //#endregion

};

module.exports = Request;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=HttpRequest.js.map
        