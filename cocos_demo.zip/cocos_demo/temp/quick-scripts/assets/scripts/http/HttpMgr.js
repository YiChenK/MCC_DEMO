(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/http/HttpMgr.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '525bclVBDJJBYikvzlSL/bN', 'HttpMgr', __filename);
// scripts/http/HttpMgr.js

"use strict";

// create bg YiChen
// @ Magic Cube
// 2018 /8/

var HttpMgr = {
    /**
    * 统一模板 Get 请求
    * @param {*} port 接口路由
    * @param {*} json 请求参数
    * @param {*} name 方法名字
    * @param {*} time 超时时间
    * @param {*} sucFn 成功回调
    * @param {*} errFn 失败回调
    */
    Get: function Get(port, sucFn, errFn, name, json, time) {
        this.Get_HTTP(port, json, time).then(function (json) {
            cc.mm.LogMgr.Resolve(name, json);

            if (!cc.mm.Tool.IsNullOrEmpty(json)) {
                if (!cc.mm.Tool.IsNullOrEmpty(sucFn)) sucFn(json.data);
            } else {
                if (!cc.mm.Tool.IsNullOrEmpty(sucFn)) sucFn();
            }
        }).catch(function (json) {
            cc.mm.LogMgr.Reject(name, json);

            if (!cc.mm.Tool.IsNullOrEmpty(errFn)) errFn();
        });
    },

    /**
    * 统一模板 Post 请求
    * @param {*} port 接口路由
    * @param {*} json 请求参数
    * @param {*} name 方法名字
    * @param {*} time 超时时间
    * @param {*} sucFn 成功回调
    * @param {*} errFn 失败回调
    */
    Post: function Post(port, sucFn, errFn, name, json, time) {
        this.Post_HTTP(port, json, time).then(function (json) {
            cc.mm.LogMgr.Resolve(name, json);

            if (!cc.mm.Tool.IsNullOrEmpty(json)) {
                if (!cc.mm.Tool.IsNullOrEmpty(sucFn)) sucFn(json.result);
            } else {
                if (!cc.mm.Tool.IsNullOrEmpty(sucFn)) sucFn();
            }
        }).catch(function (json) {
            cc.mm.LogMgr.Reject(name, json);

            if (!cc.mm.Tool.IsNullOrEmpty(errFn)) errFn();
        });
    },

    /**
     * Http Get Request
     * @param {*} path 请求路由
     * @param {*} data 请求参数
     * @param {*} time 请求超时
     */
    Get_HTTP: function Get_HTTP(path, data, time) {
        return new Promise(function (resolve, reject) {
            cc.mm.Http.get({
                root: cc.mm.Config.HTTPURL,

                path: path,

                time: time || 15000,

                data: data || {},

                //headOparetion:{ 'token': cc.sys.localStorage.getItem( "token" ) || null },

                sucFn: function sucFn(json) {
                    if (!cc.mm.Tool.IsNullOrEmpty(json.message)) {
                        cc.mm.Hint.ShowHintPush(json.message);
                    }

                    if (json.code == 200 && cc.mm.Tool.IsEmptyObject(json.error)) {
                        resolve(json);
                    } else if (json.code == 401 && cc.director.getScene().name != "loading") {
                        setTimeout(function () {
                            cc.game.restart();
                        }, 1000);
                    } else reject(json);
                },

                errFn: function errFn(json) {
                    if (!cc.mm.Tool.IsNullOrEmpty(json)) {
                        if (!cc.mm.Tool.IsNullOrEmpty(json.message)) {
                            cc.mm.Hint.ShowHintPush(json.message);
                        }

                        if (json.code == 401 && cc.director.getScene().name != "loading") {
                            setTimeout(function () {
                                cc.game.restart();
                            }, 1000);
                        }
                    }

                    reject(json);
                }
            });
        });
    },

    /**
     * Http Post Request
     * @param {*} path 请求路由
     * @param {*} data 请求参数
     * @param {*} time 请求超时
     */
    Post_HTTP: function Post_HTTP(path, data, time) {
        return new Promise(function (resolve, reject) {
            cc.mm.Http.post({
                root: cc.mm.Config.HTTPURL,

                path: path,

                time: time || 15000,

                data: data || {},

                //headOparetion:{ 'token': cc.sys.localStorage.getItem( "token" ) || null },

                sucFn: function sucFn(json) {
                    if (!cc.mm.Tool.IsNullOrEmpty(json.error) && !cc.mm.Tool.IsNullOrEmpty(json.error.message)) {
                        console.log(json.error.message); /*cc.mm.Hint.ShowHintPush( json.message ); */
                    }

                    if (json.code == 200 && cc.mm.Tool.IsEmptyObject(json.error)) {
                        resolve(json);
                    } else if (json.code == 401 && cc.director.getScene().name != "loading") {
                        setTimeout(function () {
                            cc.game.restart();
                        }, 1000);
                    } else reject(json);
                },

                errFn: function errFn(json) {
                    if (!cc.mm.Tool.IsNullOrEmpty(json)) {
                        if (!cc.mm.Tool.IsNullOrEmpty(json.message)) {
                            cc.mm.Hint.ShowHintPush(json.message);
                        }

                        if (json.code == 401 && cc.director.getScene().name != "loading") {
                            setTimeout(function () {
                                cc.game.restart();
                            }, 1000);
                        }
                    }

                    reject(json);
                }
            });
        });
    },

    Get_H5: function Get_H5(path, data, time) {
        return new Promise(function (resolve, reject) {
            cc.mm.Http.get({
                root: cc.mm.Config.H5URL,

                path: path,

                time: time || 15000,

                data: data || {},

                //headOparetion:{ 'token': cc.sys.localStorage.getItem( "token" ) || null },

                sucFn: function sucFn(data) {
                    var json = JSON.parse(data);

                    if (!cc.mm.Tool.IsNullOrEmpty(json.message)) {
                        cc.mm.Hint.ShowHintPush(json.message);
                    }

                    if (json.code == 0) {
                        resolve(json);
                    } else reject(json);
                },
                errFn: function errFn(data) {
                    if (!cc.mm.Tool.IsNullOrEmpty(data)) {
                        var json = JSON.parse(data);

                        if (!cc.mm.Tool.IsNullOrEmpty(json)) {
                            if (!cc.mm.Tool.IsNullOrEmpty(json.message)) cc.mm.Hint.ShowHintPush(json.message);
                        }
                    }

                    reject();
                }

            });
        });
    },

    Post_H5: function Post_H5(path, data, time) {
        return new Promise(function (resolve, reject) {
            cc.mm.Http.post({
                root: cc.mm.Config.H5URL,

                path: path,

                time: time || 15000,

                data: data || {},

                //headOparetion:{ 'token': cc.sys.localStorage.getItem( "token" ) || null },

                sucFn: function sucFn(data) {
                    var json = JSON.parse(data);

                    if (!cc.mm.Tool.IsNullOrEmpty(json.message)) {
                        cc.mm.Hint.ShowHintPush(json.message);
                    }

                    if (json.code == 0) {
                        resolve(json);
                    } else reject(json);
                },
                errFn: function errFn(data) {
                    if (!cc.mm.Tool.IsNullOrEmpty(data)) {
                        var json = JSON.parse(data);

                        if (!cc.mm.Tool.IsNullOrEmpty(json)) {
                            if (!cc.mm.Tool.IsNullOrEmpty(json.message)) cc.mm.Hint.ShowHintPush(json.message);
                        }
                    }

                    reject();
                }

            });
        });
    }
};

module.exports = HttpMgr;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=HttpMgr.js.map
        