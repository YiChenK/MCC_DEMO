(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/http/http.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'f3f22cla2pI1axjc4ptttBD', 'http', __filename);
// scripts/http/http.js

// create bg YiChen
// @ Magic Cube
// 2018 /8/

'use strict';

var Http = {};

Http.version = '0.0.2';
window.Http = Http;

Http.get = function (data) {
  var url = data.root + data.path; //访问地址
  var time = data.time || 15000; //设置超时
  var sucFn = data.sucFn || new Function(); //成功回调
  var errFn = data.errFn || new Function(); //失败回调
  var headOparetion = {}; //头部信息 data.headOparetion ||
  new GetReq(url, data.data, sucFn, errFn, time, data.withCredentials, headOparetion); //创建请求
};

Http.post = function (data) {
  var url = data.root + data.path; //访问地址
  var time = data.time || 15000; //设置超时
  var sucFn = data.sucFn || new Function(); //成功回调
  var errFn = data.errFn || new Function(); //失败回调
  var headOparetion = {}; //头部信息  data.headOparetion ||
  new PostReq(url, data.data, sucFn, errFn, time, data.withCredentials, headOparetion); //创建请求
};

/**
   * 创建一个get的数据请求
   * @param {*} url     访问地址
   * @param {*} data    传入参数
   * @param {*} sucFn   成功回调
   * @param {*} errFn   失败回调
   */
function GetReq(url, data, sucFn, errFn, time, withCredentials, headOparetion) {
  var xhr = createXhr();

  url += '?';

  var datastr = '';

  for (var i in data) {
    datastr += i + '=' + data[i] + '&';
  }

  datastr = datastr.slice(0, datastr.length - 1);

  url += datastr;

  //xhr.withCredentials = withCredentials || false;

  xhr.open('get', encodeURI(url), true);

  // xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded'); // 为get方式设置请求头

  for (var key in headOparetion) {
    xhr.setRequestHeader(key, headOparetion[key]);
  }

  new OnreadyStateChange(xhr, sucFn, errFn, time);

  xhr.send();
}

/**
   * 创建一个post请求
   * @param {*} url     访问地址
   * @param {*} data    传入参数
   * @param {*} sucFn   成功回调
   * @param {*} errFn   失败回调
   */
function PostReq(url, data, sucFn, errFn, time, withCredentials, headOparetion) {
  var xhr = createXhr();

  var datastr = '';

  for (var i in data) {
    datastr += i + '=' + data[i] + '&';
  }

  datastr = datastr.slice(0, datastr.length - 1);

  //xhr.withCredentials = withCredentials || false;

  xhr.open('post', url, true);

  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

  for (var key in headOparetion) {
    xhr.setRequestHeader(key, headOparetion[key]);
  }

  new OnreadyStateChange(xhr, sucFn, errFn, time);

  xhr.send(datastr);
}

function FormReq() {}

/**
   * 监听当前的xml的变化
   * @param {*} xhr     请求句柄
   * @param {*} sucFn   成功回调
   * @param {*} errFn   失败回调
   */
function OnreadyStateChange(xhr, sucFn, errFn, time) {
  var timeout = setTimeout(function () {
    execFn(errFn);
  }, time);

  xhr.onreadystatechange = function () {
    if (xhr.readyState == 4) {
      var json = JSON.parse(JSON.stringify(xhr.responseText).replace(/\s*/g, ""));

      json = JSON.parse(json);

      json.code = xhr.status;

      if (xhr.status == 200) {
        clearTimeout(timeout);
        execFn(sucFn, json);
      } else if (xhr.status == 400 || xhr.status == 401 || xhr.status == 403 || xhr.status == 404 || xhr.status == 500 || xhr.status == 503) {
        execFn(errFn, json);
      } else {
        execFn(errFn, json);

        cc.mm.LogMgr.Print("CODE = ", xhr.status);
      }
    }
  };
}

/**
   * 执行函数
   * @param {*} fn    回调方法
   * @param {*} data  返回数据
   */
function execFn(fn, json) {
  var fn = fn || new Function('');

  try {
    cc.mm.LogMgr.Json(json);

    fn(json);
  } catch (error) {
    console.log("execFn_error____");console.log(error);console.log("____error_execFn");
  }
}

/**
   * 创建一个网络请求句柄
   */
function createXhr() {
  return window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
}

// export default Http

// module.exports = Http;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=http.js.map
        