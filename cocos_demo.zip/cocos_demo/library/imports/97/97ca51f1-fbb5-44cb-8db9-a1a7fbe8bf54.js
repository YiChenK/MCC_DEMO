"use strict";
cc._RF.push(module, '97ca5Hx+7VEy425oaf76L9U', 'Dust');
// scripts/Dust.js

'use strict';

cc.Class({
    extends: require('SceneObject'),

    properties: {
        anim: cc.Animation
    },

    // use this for initialization
    playAnim: function playAnim(animName) {
        this.anim.play(animName);
    },
    finish: function finish() {
        this.node.removeFromParent();
        D.sceneManager.putIntoPool(this);
    }
});

cc._RF.pop();