"use strict";
cc._RF.push(module, '5026dczn8lKZpq2Z+LGadpZ', 'PipeGroup');
// scripts/PipeGroup.js

'use strict';

cc.Class({
    extends: require('SceneObject'),
    properties: {
        botYRange: cc.v2(0, 0),
        spacingRange: cc.v2(0, 0),
        topPipe: cc.Node,
        botPipe: cc.Node
    },
    onEnable: function onEnable() {
        var botYPos = this.botYRange.x + Math.random() * (this.botYRange.y - this.botYRange.x);
        var space = this.spacingRange.x + Math.random() * (this.spacingRange.y - this.spacingRange.x);
        var topYPos = botYPos + space;
        this.topPipe.y = topYPos;
        this.botPipe.y = botYPos;
    }
});

cc._RF.pop();