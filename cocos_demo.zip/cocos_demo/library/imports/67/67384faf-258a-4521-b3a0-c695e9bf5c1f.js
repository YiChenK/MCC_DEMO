"use strict";
cc._RF.push(module, '67384+vJYpFIbOgxpXpv1wf', 'Globals');
// scripts/Globals.js

"use strict";

// declare global variable "D"
window.D = {
    // types
    Load: null,
    GameManager: null,
    // singletons
    game: null,
    pipeManager: null,
    sceneManager: null,
    starManager: null,
    drillerManager: null,
    sheep: null
};

cc._RF.pop();