"use strict";
cc._RF.push(module, '8b031RzXH9AIYRUR8oru23d', 'LogMgr');
// scripts/http/LogMgr.js

"use strict";

// create bg YiChen
// @ Magic Cube
// 2018 /8/

var LogCtrl = {

    isSend: 0,
    console: 1,

    LOG: cc.Enum({ FALSE: 0, TRUE: 1 }),

    Json: function Json(json) {
        if (this.console == this.LOG.TRUE) {
            console.log("Json___", json);
        }
    },

    Print: function Print(info) {
        if (this.console == this.LOG.TRUE) {
            console.log("Print___", info);
        }
    },

    Error: function Error(info) {
        if (this.console == this.LOG.TRUE) {
            console.log("Error___", info);
        }
    },

    Warning: function Warning(info) {
        if (this.console == this.LOG.TRUE) {
            console.log(">>>" + info + "<<<");
        }
    },

    Success: function Success(name, info) {
        if (this.console == this.LOG.TRUE) {
            console.log("Success___", name, info);
        }
    },

    Failure: function Failure(name, info) {
        if (this.console == this.LOG.TRUE) {
            console.log("Failure___", name, info);
        }
    },

    Resolve: function Resolve(name, json) {
        if (this.console == this.LOG.TRUE) {
            console.log("Resolve___", name, json);
        }
    },

    Reject: function Reject(name, json) {
        if (this.console == this.LOG.TRUE) {
            console.log("Reject___", name, json);
        }
    },

    PortNormal: function PortNormal() {
        if (this.console == this.LOG.TRUE) {
            console.log(">>> NO NEED CALLBACK <<<");
        }
    },

    PortFunName: function PortFunName(method) {
        if (this.console == this.LOG.TRUE) {
            console.log(">>>" + method + "IS RETURN FAILED <<<");
        }
    },

    PortFunInfo: function PortFunInfo(method, data) {
        if (this.console == this.LOG.TRUE) {
            console.log(">>>" + method + data + "<<<");
        }
    },

    Socket_Send: function Socket_Send(route, data) {
        var debug = {
            TITLE: "REQUEST_TO_SEND_MSG",
            TIME: new Date(),
            PORT: route,
            DATA: data
        };

        console.log(debug);
    },

    Socket_Event: function Socket_Event(route, data) {
        var debug = {
            TITLE: "RECEIVE_TRANSMIT_MSG",
            TIME: new Date(),
            PORT: route,
            DATA: data
        };

        console.log(debug);
    },

    Socket_Error: function Socket_Error(route, data, error) {
        var debug = {
            TITLE: "--------ERROR--------",
            TIME: new Date(),
            PORT: route,
            DATA: data
        };

        if (error) {
            console.log(error);
        }

        console.log(debug);
    },

    Socket_Receive: function Socket_Receive(route, data) {
        var debug = {
            TITLE: "RECEIVE_RESPONSE_MSG",
            TIME: new Date(),
            PORT: route,
            DATA: data
        };

        console.log(debug);
    }
};

module.exports = LogCtrl;

cc._RF.pop();