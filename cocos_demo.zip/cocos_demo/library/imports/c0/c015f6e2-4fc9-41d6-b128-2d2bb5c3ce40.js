"use strict";
cc._RF.push(module, 'c015fbiT8lB1rEoLSu1w85A', 'NetConfig');
// scripts/http/NetConfig.js

"use strict";

// create bg YiChen
// @ Magic Cube
// 2018 /8/

var NetConfig = {

    OPENID: "",

    /* 端口 */
    DEFUALTPORT: 7000, //默认端口
    NORMALPORT: 7200, //长链端口
    SMALLPROT: 7001, //微服端口
    GAMEPORT: 7500, //游戏端口

    DEVICEID: "", // 设备ID
    DEIVCETYPE: "", //设备类型

    /* 地址 */
    H5URL: "", //网页地址
    HTTPURL: "", //短链地址
    SOCKETURL: "", //长链地址

    /* 配置 */
    URL_CONFIG: "/player/config", //系统配置


    /* 商城 */
    URL_SHOP_LIST: "/player/recharge/balance", //商品列表  

    /* 用户 */
    URL_LOGIN_CODE: "/php/run/user/getcode", //短信验证
    URL_USER_LOGIN: "/php/run/user/authlogin", //用户登陆
    URL_USER_CREAT: "/php/run/user/createtoken", // 挖矿

    /* enum 运行环境 */
    ENUM_ENVIR: cc.Enum({
        TEST: 1,
        DEVELOP: 2,
        RELEASE: 3,
        LOCAL: 4
    }),

    /* enum 默认登录 */
    TOKEN: cc.Enum({
        NO: 0,
        YICHEN: 1,

        properties: {
            0: "",
            1: "827e15de-6f14-4304-bf88-d521d193fdfe"
        }
    }),

    /* 初始化配置 */
    InitConfig: function InitConfig(environment) {
        if (environment == this.ENUM_ENVIR.TEST) {
            this.H5URL = "";

            this.HTTPURL = "";

            this.SOCKETURL = "";

            cc.mm.LogMgr.Print("TEST");
        } else if (environment == this.ENUM_ENVIR.DEVELOP) {
            this.H5URL = "";

            this.HTTPURL = "";

            this.SOCKETURL = ""; // 天堂鸟IP： 192.168.4.226  // 柠檬IP：192.168.4.72  // 开发 develop.mofangvr.com

            cc.mm.LogMgr.Print("DEVELOP");
        } else if (environment == this.ENUM_ENVIR.RELEASE) {
            this.H5URL = "";

            this.HTTPURL = "";

            this.SOCKETURL = "";

            cc.mm.LogMgr.Print("RELEASE");
        } else {
            // 配合服务器本机调试。
            this.H5URL = "http://192.168.4.200/";

            this.HTTPURL = "http://192.168.4.200:8081";

            this.SOCKETURL = "http://192.168.4.200";

            cc.mm.LogMgr.Print("LOCAL");
        }
    }
};

module.exports = NetConfig;

cc._RF.pop();