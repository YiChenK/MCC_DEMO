"use strict";
cc._RF.push(module, 'a3540dMSbNA0IxpobUt8I4j', 'StarManager');
// scripts/StarManager.js

'use strict';

var Star = require('Star');

cc.Class({
    extends: cc.Component,
    properties: {
        starPrefab: cc.Prefab,
        spawnInterval: 2,
        probableValue: {
            default: 0.1,
            tooltip: '生成星星的概率'
        }
    },
    onLoad: function onLoad() {
        D.starManager = this;
    },
    start: function start() {
        this.schedule(this.spawn, this.spawnInterval, cc.macro.REPEAT_FOREVER, this.spawnInterval / 2);
    },
    spawn: function spawn() {
        if (Math.random() > this.probableValue) {
            return;
        }
        var star = D.sceneManager.spawn(this.starPrefab, Star);
        star.node.y = -270 + Math.random() * (325 + 270);
    },
    reset: function reset() {
        this.unschedule(this.spawn);
    }
});

cc._RF.pop();