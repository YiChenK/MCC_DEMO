"use strict";
cc._RF.push(module, '80271xjFbZOg5XRmHf6EPDi', 'Star');
// scripts/Star.js

'use strict';

cc.Class({
    extends: require('SceneObject')
});

cc._RF.pop();