package webview;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;

/**
 * Created by szc on 2017/7/26.
 */

public class WebDeal {
    public static Activity activity;
    public static void setActivity(Activity activity){
         WebDeal.activity = activity;
    }
    public static void startWeb(String url){
        Intent intent = new Intent(activity.getApplicationContext(), webview.webActivity.class);
        intent.putExtra("url", url);
        activity.startActivity(intent);
    }
}
