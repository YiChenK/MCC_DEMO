package webview;

import android.app.Activity;
import android.webkit.JavascriptInterface;

/**
 * Created by szc on 2017/7/26.
 */

public class WebTesk {
    private Activity activity;
    WebTesk(Activity activity){
        this.activity = activity;
    }
    @JavascriptInterface
    public void closeWeb(){
       activity.finish();
    }
}
